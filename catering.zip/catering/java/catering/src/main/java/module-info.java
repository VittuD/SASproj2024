module catering {
    requires java.sql;
    requires com.google.gson;
    exports catering;
}
