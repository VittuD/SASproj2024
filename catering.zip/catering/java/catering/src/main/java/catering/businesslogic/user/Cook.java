package catering.businesslogic.user;

public class Cook {
    private String name;

    public Cook(String name) {
        this.name = name;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
