package catering.businesslogic.turn;

public class ServiceTurn extends Turn{

}
