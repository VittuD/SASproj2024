package catering.businesslogic.turn;

public class KitchenTurn extends Turn {
    private  Boolean full;

    private Kitchen kitchen;


}
