package catering.businesslogic.turn;

public class Recurrency {
    /*stub*/
}
